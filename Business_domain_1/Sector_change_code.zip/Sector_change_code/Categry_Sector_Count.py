 # import the mrjob library
from mrjob.job import MRJob

# creat the class
class ChangeCategry_Sector_Count(MRJob): 
    
    
    # in the map step each row in dataframe is read key for each value pair
    def mapper(self,_,sector_change ):
     
        yield (sector_change, 1) 
        # The output for each row as a tuple 
        

    # in the reduce step combine all tuples with the same key
    # after that  sum all the values of the tuple, which will give the total 
    def reducer(self, key, values):
        yield (key, sum(values))
        
if __name__ == "__main__":
    ChangeCategry_Sector_Count.run()
